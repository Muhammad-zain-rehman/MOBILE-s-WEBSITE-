s<?php

	// this will avoid mysql_connect() deprecation error.
	error_reporting( ~E_DEPRECATED & ~E_NOTICE );
	// but I strongly suggest you to use PDO or MySQLi.
	
$mysql=new mysqli("localhost","root","","mobile");

$errornum=mysqli_connect_errno();
$error=mysqli_connect_error();

if($errornum){

	echo $errornum." ". $error;
	echo "Not connected";
}
else
{
	echo"connected";
}
