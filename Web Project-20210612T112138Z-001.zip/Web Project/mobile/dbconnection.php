<?php
$servername="localhost";
$username="root";
$password="";
$database="Mobile";
$mysql=mysqli_connect($servername,$username,$password,$database);
$errno=mysqli_connect_errno();
$error=mysqli_connect_error();
if($mysql)
{
  //echo"connected";
}
else
{
	echo $errno ." ".$error;
	echo " not connect....!!";
}

?>