<?php
$mysql=new mysqli("localhost","root","","codexworld");

$errornum=mysqli_connect_errno();
$error=mysqli_connect_error();

if($errornum){

	echo $errornum." ". $error;
	echo "Not connected";
}
else
{
	echo"connected";
}






?>