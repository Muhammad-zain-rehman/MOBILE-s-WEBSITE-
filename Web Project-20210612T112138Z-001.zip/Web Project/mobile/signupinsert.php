<?php
 
require("dbconnect.php");
$name=$_POST['Name'];
$email=$_POST['Email'];
$Password=$_POST['password'];
$mobile=$_POST['PhoneNumber'];

$insert=$mysql->query("INSERT INTO signup(name,email,password,mobile)values('$name','email','password','mobile')");
if($insert)
{
		header("Location: home.php");
}
else
{
  //echo "not connect";
}

?>